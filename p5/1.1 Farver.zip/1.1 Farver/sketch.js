/*
1. Code below is for https://youtu.be/D1ELEeIs0j8?list=PLRqwX-V7Uu6Zy51Q-x9tMWIv9cueOFTFA
2. Code is at 7:57 seconds on drawing rectangle
*/


function setup() {
    createCanvas(640, 360);
}

function draw() {
    background(255,204,0);
    fill('#fae');
    noStroke();
    ellipse(320, 180, 55, 55);
}